package com.bsc.qa.facets.gl_extract_validation;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		String str = "-00000000001407";
		Integer integer = Integer.parseInt(str);
		int number = integer / 100;
		String num = "";
		int decimal = integer % 100;
		if(str.charAt(0)=='-') {
			decimal *= -1;
		}
		
		String dec = "";
		if (number == 0) {
			num = number + "0";
		} else {
			num = "" + number;
		}
		if (decimal == 0) {
			dec = decimal + "0";
		}else if(decimal<10) {
			dec = "0" + decimal;
		}
		else {
			dec = "" + decimal;
		}
		
		System.out.println(num+"."+dec);
	}

	
}
