package com.bsc.qa.facets.gl_extract_validation.parser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;

import com.bsc.qa.facets.gl_extract_validation.pojo.GLHeader;
import com.bsc.qa.facets.gl_extract_validation.pojo.GLTrailer;
import com.bsc.qa.facets.gl_extract_validation.pojo.GlExtract;
import com.bsc.qa.facets.gl_extract_validation.pojo.GlRecordDetail;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.RecordType;

public class FileParser {
	
	
	public static String filename ;
	public File inputFile;
	
	
	public GlExtract parseFile() throws IOException  {
		String directoryName = System.getenv("GLEXTRACT_FILE_FOLDER_LOCATION");
		inputFile = getMatchingAndLatestFile(directoryName, "*.txt");
		filename = inputFile.getAbsolutePath();
		System.out.println("Input file - "+inputFile.getName());
		
		GlExtract extract  = new GlExtract();
		
		
		if (!inputFile.exists()) {
			throw new IllegalStateException("File not found: " + filename);
		}
		
		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(GlRecordDetail.class);
		ffDefinition.setHeader(GLHeader.class);
		ffDefinition.setTrailer(GLTrailer.class);
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		for (Object record : ffReader) {
			RecordType recordType = ffReader.getRecordType();
			if (recordType == RecordType.HEADER) {
				GLHeader header = (GLHeader)record;
				extract.setGlHeader(header);
			} else if (recordType == RecordType.BODY) {
				GlRecordDetail glRecord = (GlRecordDetail)record;
				glRecord.setAmount(getNormalAmountFields(glRecord.getAmount()));
				extract.getGlRecordDetailList().add(glRecord);
				
			} else if (recordType == RecordType.TRAILER) {
				GLTrailer trailer = (GLTrailer)record;
				extract.setGlTrailer(trailer);
			}
		}
		ffReader.close();
		
		return extract;
	}
	
	public File getMatchingAndLatestFile(String directoryName,String wildcard) throws FileNotFoundException{
		{
		    File directory = new File(directoryName);
		    Collection<File> files = FileUtils.listFiles(directory, new WildcardFileFilter(wildcard), null);
		    if(files.isEmpty()){
		    	throw new FileNotFoundException("No files matching specified pattern -" + wildcard );
		    }
		    File latestFile = null;
		    Long lastModified = new Long(0) ;
		    for (File file : files) {
		    	if(lastModified<file.lastModified()){
				lastModified = file.lastModified();
				latestFile = file;
		    	}
			}
		    return latestFile;
		}
	}
	
	public String getNormalAmountFields(String str) {
		Integer integer = Integer.parseInt(str);
		int number = integer / 100;
		String num = "";
		int decimal = integer % 100;
		if(str.charAt(0)=='-') {
			decimal *= -1;
		}
		
		String dec = "";
		if (number == 0) {
			num = number + "0";
		} else {
			num = "" + number;
		}
		if (decimal == 0) {
			dec = decimal + "0";
		}else if(decimal<10) {
			dec = "0" + decimal;
		}
		else {
			dec = "" + decimal;
		}
		
		return num+"."+dec;
	}

}
