package com.bsc.qa.facets.gl_extract_validation.pojo;

import java.util.ArrayList;
import java.util.List;

public class GlExtract {

	private GLHeader glHeader;
	private List<GlRecordDetail> glRecordDetailList = new ArrayList<GlRecordDetail>();
	private GLTrailer glTrailer;
	
	public GLHeader getGlHeader() {
		return glHeader;
	}
	public void setGlHeader(GLHeader glHeader) {
		this.glHeader = glHeader;
	}
	public List<GlRecordDetail> getGlRecordDetailList() {
		return glRecordDetailList;
	}
	public void setGlRecordDetailList(List<GlRecordDetail> glRecordDetailList) {
		this.glRecordDetailList = glRecordDetailList;
	}
	public GLTrailer getGlTrailer() {
		return glTrailer;
	}
	public void setGlTrailer(GLTrailer glTrailer) {
		this.glTrailer = glTrailer;
	}
	
	
	
}
