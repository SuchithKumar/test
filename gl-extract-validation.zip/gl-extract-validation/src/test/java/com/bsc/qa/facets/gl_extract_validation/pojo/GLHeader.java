package com.bsc.qa.facets.gl_extract_validation.pojo;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class GLHeader {

	private String headerIndicator;
	private String jeNumber;
	private String cycleDate;
	private String jeCategory;
	private String jeSource;
	
	@PositionalField(initialPosition = 1,finalPosition = 1)
	public String getHeaderIndicator() {
		return headerIndicator;
	}
	
	@PositionalField(initialPosition = 3,finalPosition = 32)
	public String getJeNumber() {
		return jeNumber;
	}
	
	@PositionalField(initialPosition = 33,finalPosition = 40)
	public String getCycleDate() {
		return cycleDate;
	}
	
	@PositionalField(initialPosition = 41,finalPosition = 65)
	public String getJeCategory() {
		return jeCategory;
	}
	
	@PositionalField(initialPosition = 66,finalPosition = 88)
	public String getJeSource() {
		return jeSource;
	}
	
	public void setHeaderIndicator(String header) {
		this.headerIndicator = header;
	}
	public void setJeNumber(String jeNumber) {
		this.jeNumber = jeNumber;
	}
	public void setCycleDate(String cycleDate) {
		this.cycleDate = cycleDate;
	}
	public void setJeCategory(String jeCategory) {
		this.jeCategory = jeCategory;
	}
	public void setJeSource(String jeSource) {
		this.jeSource = jeSource;
	}

	@Override
	public String toString() {
		return "GLHeader [headerIndicator=" + headerIndicator + ", jeNumber=" + jeNumber + ", cycleDate=" + cycleDate
				+ ", jeCategory=" + jeCategory + ", jeSource=" + jeSource + "]";
	}

	
	
	
}
