package com.bsc.qa.facets.gl_extract_validation.pojo;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class GLTrailer {

	private String trailerIndicator;
	private String countOfRecords;
	private String totalDebitAmount;
	private String totalCreditAmount;
	
	@PositionalField(initialPosition = 1,finalPosition = 1)
	public String getTrailerIndicator() {
		return trailerIndicator;
	}
	
	@PositionalField(initialPosition = 3,finalPosition = 17)
	public String getCountOfRecords() {
		return countOfRecords;
	}
	
	@PositionalField(initialPosition = 19,finalPosition = 42)
	public String getTotalDebitAmount() {
		return totalDebitAmount;
	}
	
	@PositionalField(initialPosition = 43,finalPosition = 66)
	public String getTotalCreditAmount() {
		return totalCreditAmount;
	}
	
	public void setTrailerIndicator(String trailerIndicator) {
		this.trailerIndicator = trailerIndicator;
	}
	public void setCountOfRecords(String countOfRecords) {
		this.countOfRecords = countOfRecords;
	}
	public void setTotalDebitAmount(String totalDebitAmount) {
		this.totalDebitAmount = totalDebitAmount;
	}
	public void setTotalCreditAmount(String totalCreditAmount) {
		this.totalCreditAmount = totalCreditAmount;
	}

	@Override
	public String toString() {
		return "GLTrailer [trailerIndicator=" + trailerIndicator + ", countOfRecords=" + countOfRecords
				+ ", totalDebitAmount=" + totalDebitAmount + ", totalCreditAmount=" + totalCreditAmount + "]";
	}

	
}
