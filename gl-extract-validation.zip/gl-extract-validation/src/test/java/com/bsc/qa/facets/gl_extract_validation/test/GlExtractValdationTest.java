package com.bsc.qa.facets.gl_extract_validation.test;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;

import org.assertj.core.api.SoftAssertions;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.bsc.qa.facets.gl_extract_validation.parser.FileParser;
import com.bsc.qa.facets.gl_extract_validation.pojo.GlExtract;
import com.bsc.qa.facets.gl_extract_validation.pojo.GlRecordDetail;
import com.bsc.qa.framework.base.BaseTest;
import com.bsc.qa.framework.utility.DBUtils;
import com.bsc.qa.framework.utility.ExcelUtils;
import com.relevantcodes.extentreports.LogStatus;


public class GlExtractValdationTest extends BaseTest implements IHookable {
	
	private DBUtils dbUtils = new DBUtils();
	private Map<String, String> dataMap = new HashMap<String, String>();

	private GlExtract glExtract = new GlExtract();
	private Map<String, GlRecordDetail> glMap = new HashMap<>();
	
	private SoftAssertions softAssertions;
	
	
	@BeforeSuite
	public void beforeSuite() {
		FileParser parser = new FileParser();
		try {
			glExtract = parser.parseFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	
		
	@BeforeTest
	public void beforeTest() {
	
		for(GlRecordDetail glRecordDetail : glExtract.getGlRecordDetailList()) {
			String key = glRecordDetail.getExtJENumber();
			if(!glMap.containsKey(key)) {
				glMap.put(key, glRecordDetail);
			}
		}
		
	}
		
	@Test
	public void testTrailerRecord() throws ParseException {
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/"+ this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testGlTrailer");
		FileParser parser = new FileParser();
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddyyyy");
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MMM-yy");
		
		String cycleDate = glExtract.getGlHeader().getCycleDate();
		
		cycleDate  = simpleDateFormat2.format(simpleDateFormat.parse(cycleDate)).toUpperCase();
		
		SortedMap<String, SortedMap<String, String>> dbMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),"DR_CR_IND",cycleDate);
		
		String dbCreditAmount = dbMap.get("C").get("SUM(TRANS_AMT)");
		String dbDebitAmount = dbMap.get("D").get("SUM(TRANS_AMT)");
		String fileCreditAmount = parser.getNormalAmountFields(glExtract.getGlTrailer().getTotalCreditAmount());
		String fileDebitAmount = parser.getNormalAmountFields(glExtract.getGlTrailer().getTotalDebitAmount());
		
		softAssertions.assertThat(dbCreditAmount).as("Credit amount mismatch with DB").isEqualTo(fileCreditAmount);
		softAssertions.assertThat(dbDebitAmount).as("Debit amount mismatch with DB").isEqualTo(fileDebitAmount);
		
		Integer actualTotalDetailRecordRows = glExtract.getGlRecordDetailList().size();
		Integer expectedTotalDetailRecordRows = Integer.parseInt(glExtract.getGlTrailer().getCountOfRecords());
		BigInteger totalDebitAmount  = BigInteger.valueOf(Long.parseLong(glExtract.getGlTrailer().getTotalCreditAmount())).abs();
		BigInteger totalCreditAmount  =  BigInteger.valueOf(Long.parseLong(glExtract.getGlTrailer().getTotalDebitAmount())).abs();
		
		softAssertions.assertThat(actualTotalDetailRecordRows).as("Record Count mismatch in trailer").isEqualByComparingTo(expectedTotalDetailRecordRows);
		softAssertions.assertThat(totalCreditAmount).as("Credit/Debit amount mismatch in trailer").isEqualTo(totalDebitAmount);
		
	}
	
	@Test
	public void testGlRecordDetail() throws ParseException {
		String xlsPath = new File("").getAbsolutePath()+ "/src/test/resources/"+ this.getClass().getSimpleName() + ".xlsx";
		dataMap = ExcelUtils.getTestMethodData(xlsPath, "testGlRecordDetail");
				
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddyyyy");
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MMM-yy");
		
		String cycleDate = glExtract.getGlHeader().getCycleDate();
		
		cycleDate  = simpleDateFormat2.format(simpleDateFormat.parse(cycleDate)).toUpperCase();
		
		System.out.println("Cycle Data "+cycleDate);
		SortedMap<String, SortedMap<String, String>> dbMap = dbUtils.getMultiRowsFromPreparedQuery("facets", dataMap.get("PREPARED_STATEMENT_QUERY"),"EXTR_JRNL_NBR_TXT",cycleDate);
		
		for(Entry<String, SortedMap<String, String>> dbMapEntry : dbMap.entrySet()) {
			
			String key = dbMapEntry.getKey();
			GlRecordDetail glRecordFile = glMap.get(key);
			String lglEntityDb = dbMapEntry.getValue().get("LGL_ENTY_CD");
			String glActNumber = dbMapEntry.getValue().get("GL_ACCT_NBR_TXT");
			String productBusCat = dbMapEntry.getValue().get("PRDCT_BUS_CATEG_CD");
			String productValCode = dbMapEntry.getValue().get("PRDCT_VAL_1_CD");
			String groupTypeCode = dbMapEntry.getValue().get("GRP_TYP_CD");
			String benefitCategoryCode = dbMapEntry.getValue().get("BNF_CATEG_CD");
			String sumTransAmount = dbMapEntry.getValue().get("SUM(TRANS_AMT)");
			
			softAssertions.assertThat(glRecordFile.getLegalEntity()).as("Legal Entity mismatch for EXTR_JRNL_NBR_TXT :"+key).containsIgnoringCase(lglEntityDb);
			softAssertions.assertThat(glRecordFile.getGlNumber()).as("GL Account Number mismatch for EXTR_JRNL_NBR_TXT :"+key).containsIgnoringCase(glActNumber);
			softAssertions.assertThat(glRecordFile.getBusinessCategory()).as("Business Category mismatch for EXTR_JRNL_NBR_TXT :"+key).containsIgnoringCase(productBusCat);
			softAssertions.assertThat(glRecordFile.getPlanCategory()).as("Plan Category Type mismatch for EXTR_JRNL_NBR_TXT :"+key).containsIgnoringCase(productValCode);
			softAssertions.assertThat(glRecordFile.getGrpMiscTyp()).as("Group Misc mismatch for EXTR_JRNL_NBR_TXT :"+key).containsIgnoringCase(groupTypeCode);
			softAssertions.assertThat(glRecordFile.getChannel()).as("Benefit Category mismatch for EXTR_JRNL_NBR_TXT :"+key).containsIgnoringCase(benefitCategoryCode);
			softAssertions.assertThat(Double.parseDouble(glRecordFile.getAmount())).as("Amount mismatch for EXTR_JRNL_NBR_TXT :"+key).isEqualTo(Double.parseDouble(sumTransAmount));
			
			
		}
	
	}

	
	
	
	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		reportInit(testResult.getTestContext().getName(), testResult.getName(),"");
		softAssertions = new SoftAssertions();
		logger.log(LogStatus.INFO, "Starting test " + testResult.getName());
		callBack.runTestMethod(testResult);
		softAssertions.assertAll();
		
	}
	
	
	
	
}
