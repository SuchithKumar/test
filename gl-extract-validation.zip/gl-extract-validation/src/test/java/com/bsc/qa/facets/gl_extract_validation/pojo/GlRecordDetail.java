package com.bsc.qa.facets.gl_extract_validation.pojo;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class GlRecordDetail {

	private String detail;
	private String legalEntity;
	private String financialRegion;
	private String glNumber;
	private String interco;
	private String businessCategory;
	private String grpMiscTyp;
	private String planCategory;
	private String channel;
	private String project;
	private String amount;
	private String extJENumber;
	
	@PositionalField(initialPosition = 1,finalPosition = 1)
	public String getDetail() {
		return detail;
	}
	@PositionalField(initialPosition = 3,finalPosition = 5)
	public String getLegalEntity() {
		return legalEntity;
	}
	@PositionalField(initialPosition = 6,finalPosition = 10)
	public String getFinancialRegion() {
		return financialRegion;
	}
	@PositionalField(initialPosition = 11,finalPosition = 20)
	public String getGlNumber() {
		return glNumber;
	}
	@PositionalField(initialPosition = 21,finalPosition = 23)
	public String getInterco() {
		return interco;
	}
	@PositionalField(initialPosition = 25,finalPosition = 28)
	public String getBusinessCategory() {
		return businessCategory;
	}
	@PositionalField(initialPosition = 29,finalPosition = 32)
	public String getGrpMiscTyp() {
		return grpMiscTyp;
	}
	@PositionalField(initialPosition = 33,finalPosition = 36)
	public String getPlanCategory() {
		return planCategory;
	}
	@PositionalField(initialPosition = 38,finalPosition = 41)
	public String getChannel() {
		return channel;
	}
	@PositionalField(initialPosition = 42,finalPosition = 49)
	public String getProject() {
		return project;
	}
	@PositionalField(initialPosition = 50,finalPosition = 64)
	public String getAmount() {
		return amount;
	}
	@PositionalField(initialPosition = 66,finalPosition = 83)
	public String getExtJENumber() {
		return extJENumber;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public void setFinancialRegion(String financialRegion) {
		this.financialRegion = financialRegion;
	}
	public void setGlNumber(String glNumber) {
		this.glNumber = glNumber;
	}
	public void setInterco(String interco) {
		this.interco = interco;
	}
	public void setBusinessCategory(String businessCategory) {
		this.businessCategory = businessCategory;
	}
	public void setGrpMiscTyp(String grpMiscTyp) {
		this.grpMiscTyp = grpMiscTyp;
	}
	public void setPlanCategory(String planCategory) {
		this.planCategory = planCategory;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public void setExtJENumber(String extJENumber) {
		this.extJENumber = extJENumber;
	}
	@Override
	public String toString() {
		return "GlRecordDetail [detail=" + detail + ", legalEntity=" + legalEntity + ", financialRegion="
				+ financialRegion + ", glNumber=" + glNumber + ", interco=" + interco + ", businessCategory="
				+ businessCategory + ", grpMiscTyp=" + grpMiscTyp + ", planCategory=" + planCategory + ", channel="
				+ channel + ", project=" + project + ", amount=" + amount + ", extJENumber=" + extJENumber + "]";
	}
	
	

}
